import React from 'react';
import Button from 'react-bootstrap/Button';
import './CustomButton.scss'

const CustomButton = (props) => {
    return (
        <div>
            <Button className='custom-button' variant="primary">{props.name}</Button>
        </div>
    )
}

export default CustomButton
