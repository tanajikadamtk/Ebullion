export const data = [
    {
      id: 1,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "In Stock",
      
    }, 
  
    {
      id: 2,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "Out of Stock",
      
    }, 
  
    {
      id: 3,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "In Stock",
      
    }, 
  
    {
      id: 4,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "Out of Stock",
      
    }, 
  
    {
      id: 5,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "In Stock",
      
    }, 
  
    {
      id: 6,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "Out of Stock",
      
    }, 
  
    {
      id: 7,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "In Stock",
      
    }, 
  
    {
      id: 8,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "In Stock",
      
    }, 
  
    {
      id: 9,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "Out of Stock",
      
    }, 
  
    {
      id: 10,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "In Stock",
      
    }, 
  
    {
      id: 11,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "In Stock",
      
    }, 
  
    {
      id: 12,
      title: "Palladium",
      weight: "10 gm",
      fineness: "9995",
      status: "In Stock",
      
    }, 
  ];