import productImage from '../assets/images/product/product.svg';

export const data = [
  {
    id: 1,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "In Stock",
    image: productImage
  }, 

  {
    id: 2,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "Out of Stock",
    image: productImage
  }, 

  {
    id: 3,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "In Stock",
    image: productImage
  }, 

  {
    id: 4,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "Out of Stock",
    image: productImage
  }, 

  {
    id: 5,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "In Stock",
    image: productImage
  }, 

  {
    id: 6,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "Out of Stock",
    image: productImage
  }, 

  {
    id: 7,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "In Stock",
    image: productImage
  }, 

  {
    id: 8,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "In Stock",
    image: productImage
  }, 

  {
    id: 9,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "Out of Stock",
    image: productImage
  }, 

  {
    id: 10,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "In Stock",
    image: productImage
  }, 

  {
    id: 11,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "In Stock",
    image: productImage
  }, 

  {
    id: 12,
    title: "Palladium",
    weight: "10 gm",
    fineness: "9995",
    status: "In Stock",
    image: productImage
  }, 
];
